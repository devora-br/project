﻿using Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace Dal
{
    public class XmlData
    {
        static string path = "data.xml";
        static string searchingSavePath = "searchingSaveData.xml";
        public static string SaveSearchingData(SearchData sd)
        {

            //XDocument xDoc = new XDocument();
            //saveDataToXml(xDoc, path, sd, false);
            XDocument doc;
            if (!File.Exists(searchingSavePath))
            {
                File.Create(searchingSavePath).Dispose();
                doc = new XDocument();
            }
            else if (new FileInfo(searchingSavePath).Length == 0)
            {
                doc = new XDocument();
            }
            else
            {
                doc = XDocument.Load(searchingSavePath);
            }
            saveDataToXml(doc, searchingSavePath, sd);

            return "";
        }

        private static void saveDataToXml(XDocument xDoc, string path, SearchData sd)
        {

            XElement searchDataDocElement = null;

            searchDataDocElement = xDoc.Descendants("SearchDataItems").FirstOrDefault();
            if (searchDataDocElement == null)
            {
                searchDataDocElement = new XElement("SearchDataItems");
                xDoc.Add(searchDataDocElement);

            }
            XElement newSearchDataItem = new XElement("SearchData"
            , new XElement("SearchDate", DateTime.Now.ToString("dd/MM/yyyy HH:mm"))
            , new XElement("SourcePath", sd.SourcePath)
            , new XElement("AgainstPath", sd.AgainstPath)
            , new XElement("FileTypes", (int)sd.FileTypes)
            , new XElement("KindEquals", (int)sd.KindEquals)
            , new XElement("RangeNumber", sd.rangeNumber));

            searchDataDocElement.Add(newSearchDataItem);
            xDoc.Save(path);

        }
        public static List<SearchData> getSearchingSaveData()
        {
            List<SearchData> searchData = new List<SearchData>();
            if (!File.Exists(searchingSavePath))
            {
                File.Create(searchingSavePath).Dispose();
                return searchData;
            }
            if (new FileInfo(searchingSavePath).Length == 0)
            {
                return searchData;
            }

            var searchDataElements = XDocument.Load(searchingSavePath).Descendants("SearchData")
                        .Select(element => element).ToArray();
            foreach (var data in searchDataElements)
            {
                var searchDataItem = new SearchData()
                {
                    FileTypes = (eType)int.Parse(data.Element("FileTypes").Value),
                    KindEquals = ((eEquals)int.Parse(data.Element("KindEquals").Value)),
                    SearchDate = DateTime.Parse(data.Element("SearchDate").Value),
                    SourcePath = data.Element("SourcePath").Value,
                    AgainstPath = data.Element("AgainstPath").Value,
                    rangeNumber = data.Element("RangeNumber").Value,

                };

                searchDataItem.SearchTitle += Path.GetFileName(searchDataItem.SourcePath);
                searchDataItem.SearchTitle += " ל " + Path.GetFileName(searchDataItem.AgainstPath);
                searchDataItem.SearchTitle += " בתאריך " + searchDataItem.SearchDate.ToString("dd/MM/yyyy HH:mm") + " השוואת ";
                searchData.Add(searchDataItem);
            }


            return searchData;
        }
    }
}
